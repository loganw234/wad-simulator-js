@echo off
rem  A SYNTHETIC demo texture for wad-simulator-js -- no game art.
rem  new texture : wadsim_demo_texture  0xDC45FAC6
"%SM%" --source-wad "%WAD%" --extra-only ^
    --inject-extra 0xDC45FAC6:27:"%~dp0wadsim_demo_texture.ucfx" ^
    -o "%~dp0wadsim_demo_texture-patch.wad"